/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package penjualan;

/**
 *
 * @author user
 */
public class Transaksi1 {
    private String namaBarang;
    private int harga;

    public Transaksi1(String namaBarang, int harga) {
        this.namaBarang = namaBarang;
        this.harga = harga;
    }

    @Override
    public String toString() {
        return this.namaBarang;
    }

    /**
     * @return the namaBarang
     */
    public String getNamaBarang() {
        return namaBarang;
    }

    /**
     * @param namaBarang the namaBarang to set
     */
    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }

    /**
     * @return the satuan
     */
    
    public int getHarga() {
        return harga;
    }

    /**
     * @param harga the harga to set
     */
    public void setHarga(int harga) {
        this.harga = harga;
    }
    
}
