package penjualan;

import desain.Transaksi;

public class NewMain {

    public static void main(String[] args) {
        // TODO code application logic here
        Transaksi penjualan = new Transaksi();
        penjualan.setVisible(true);
    }
    
}
